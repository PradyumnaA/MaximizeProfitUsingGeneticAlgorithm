import random
import numpy as numpyModule


# Chromosome class represents the Chromosome
class ChromosomeGenerator:
    """
    This class generates the chromosomes along with the fitness scores

    """
    def __init__(self, numbers, gene_data):
        self.numbers = numbers
        self.fitness = -5000#Initialize the fitness score to -5000 this is used when the chromosomes do not match the genetic information
        # Sort the first two and the next two numbers in the numbers list
        self.numbers[:2] = sorted(self.numbers[:2])#sorting 0th and first index
        self.numbers[2:4] = sorted(self.numbers[2:4])#sorting second and fourth index

        self.compute_the_fitness_score(gene_data)#Here I am calling this method to caluclate the fitness score

    def compute_the_fitness_score(self, gene_data):
        self.fitness = 0.0#Initializing fitness score to 0.0
        for everyLine in gene_data:#For each and every line do the following
            
            if self.numbers[0] <= everyLine[0] <= self.numbers[1] and self.numbers[2] <= everyLine[1] <= self.numbers[3]:#if the first number of gene data lies in the range of 1st 2 numbers of chromosomes
                #and the second number of gene data lies in next 2 ranges of chromosome then do the following
                self.fitness += everyLine[2] if self.numbers[4] == 1 else -everyLine[2]#If the last digit is 1 then add up otherwise subtract to fitness score

    def __str__(self):
        return f"{','.join(map(str, self.numbers))}, fitness Scores are: {self.fitness}"#Return the chromosomes along with fitness in the string format

def load_gene_data():
    """
    This function is used to read the contents of the gene file
    """
    file_name = input("Enter the gene data file name with .txt extension: for example if you have geneAlgData1 file enter it as geneAlgData1.txt ")

    try:
        #Open the genetic datafile in read mode and convert each and every gene to a floating point number
        with open(file_name, 'r') as gene_file:
            gene_data = [[float(gene_number) for gene_number in everyLine.split()] for everyLine in gene_file]#Read each and every gene
    except FileNotFoundError:
        print(f"Error: The '{file_name}' file was not found.")#If the line is not found print the error message
        exit(1)

    return gene_data



def initialize_chromosome_with_mean_and_standard_deviation(gene_data):
    mean=0
    standard_deviation=1.15  
    choices = [0, 1]
    probabilities = [0.5, 0.5]
    chromosome = list(numpyModule.random.normal(mean, standard_deviation, 4)) + [numpyModule.random.choice(choices, p=probabilities)]#Generate the random numbers with mean0 and standard deviation 1.15
    return ChromosomeGenerator(chromosome,gene_data)


# Implement roulette wheel selection algorithm
def roulette_wheel(chromosome_population):
    """
    This method is used to caluclate the roulette wheel on basis of bias or weightage
    That is the probability of selecting chromosomes which are more desirable is being increased here
    """
    # Get the fitness
    fitness_values = [chromosome.fitness for chromosome in chromosome_population]
    # print(fitness_values)

    # If all fitness values are the same, return None
    difference_values=numpyModule.max(fitness_values)-numpyModule.min(fitness_values)
    if difference_values == 0:
        return None

    # Here the values are scaled
    make_positive_fitness = 1.0 - (fitness_values - numpyModule.min(fitness_values)) / difference_values

    # Calculate the sum of the scaled fitness values
    total_fitness = numpyModule.sum(make_positive_fitness)

    # Generate a random number between 0 and the total fitness
    random_number = numpyModule.random.uniform(0, total_fitness)

    # Select a chromosome based on the random number that is we need to select the random number or select those which have the higher fitness score
    for index, fitness_scores in enumerate(make_positive_fitness):
        random_number=random_number-fitness_scores
        if random_number <= 0:
            return chromosome_population[index]


def create_offspring_uniform_crossover(first_parent_to_be_generated, second_parent_to_be_generated, gene_data):
    """
    This method is used to perform uniform crossover
    """
    #Referencehttps://medium.com/@samiran.bera/crossover-operator-the-heart-of-genetic-algorithm-6c0fdcb405c0
    # Use list comprehension and the ternary operator to simplify the creation of the offspring chromosome
    size=5
    numbers = [first_parent_to_be_generated.numbers[index] if random.randint(0, 1) == 0 else second_parent_to_be_generated.numbers[index] for index in range(size)]#hey if the random integer generated is 0 
    #Then make use of first parent's child otherwise make use of second parent's index
    #Hey create the offspring check if the chromosome's range matches the gene's range call the method
    #After performing the crossover we are calling the respective method
    return ChromosomeGenerator(numbers, gene_data)


def create_offspring_k_point_crossover(first_parent_to_be_generated, second_parent_to_be_generated, gene_data):
    """
    This method is used to perform k_point crossover
    """
    #Here K is 2
    #Referencehttps://medium.com/@samiran.bera/crossover-operator-the-heart-of-genetic-algorithm-6c0fdcb405c0
    k=2
    numbers = first_parent_to_be_generated.numbers[:k] + second_parent_to_be_generated.numbers[k:]
    #Using the concept of list slicing to create the offspring chromosomes
    #In k_point crossover we make use of slicing and swapping
    return ChromosomeGenerator(numbers, gene_data)


def create_next_generation(population, X, Z, crossover_algorithm, gene_data):
    """
    This method is used to create a new generation or next generation
    """
    next_generation = random.sample(population, int(X * len(population)))#Randomly select the population or chromosomes
    remaining_size = len(population) - len(next_generation)#Calulcating the remaining size

    # Map the crossover algorithm names to the corresponding functions
    crossover_functions = {
        "uniform": create_offspring_uniform_crossover,
        "k_point": create_offspring_k_point_crossover
    }#Here we are defining 2 kinds of crossovers uniform and k_point crossover
    """
    Selection is defined here
    """
    for _ in range(remaining_size):
        first_parent_to_be_generted = roulette_wheel(population)#Hey select the first parent using roulette wheel method
        # print(first_parent_to_be_generted)
        second_parent_to_be_generated = roulette_wheel(population)#Hey select the second parent using roulette wheel method
        # print(second_parent_to_be_generated)
        if first_parent_to_be_generted is None:#If the first parent is None then return none
            return None
        # print(second_parent)
        if second_parent_to_be_generated is None:
            return None

        # Using the dictionary to call the apropriate algorithm
        """
        Crossover is defined here
        """
        #Choose the apropriate crossover function and generate the offspring
        offspring = crossover_functions[crossover_algorithm](first_parent_to_be_generted, second_parent_to_be_generated, gene_data)
        # print(offspring)
        next_generation.append(offspring)#Appending the offsprings to next generation

    for index, child in enumerate(next_generation):
        """
        Here we are performing mutation
        """
        has_mutation = False#We are initializing the mutation as false
        for i in range(5):#Iterating over 5 positions
            if random.random() < Z:#Here we are checking Z% mutation
                if i == 4:#If the index is 4 then
                    child.numbers[i] = random.randint(0, 1)#Generate the random number and append the last digit with either 0 or a 1
                else:
                    mean, standard_deviation = 0, 1.15#Otherwise genrate the random numbers with mean1 and standard deviation 1.15
                    num = numpyModule.random.normal(mean, standard_deviation, 1)[0]
                    child.numbers[i] = num
                has_mutation = True
        if has_mutation:#If mutation is true then regenerate the random chromosomes
            next_generation[index] = ChromosomeGenerator(child.numbers, gene_data)

    return next_generation#Returning the next generation




def get_user_input():
    """
    This function is used to get the user inputs and convert percentages to floating point and later convert it into decimal numbers
    """
    Chromosomes_Size = int(input("Enter the number of chromosomes in the population: "))#Here we are entering the total number of chromosomes which has to be generated
    print("The total number of chromosomes which would be generated is ",Chromosomes_Size)
    Num_Generations = int(input("Enter the number of generations to run the genetic algorithm: "))
    print("The number of generations is",Num_Generations)#Here we are printing the details
    
    X_percent = float(input("Enter the percentage of chromosomes to be cloned into the next generation (e.g., 10 for 10%): "))
    print("The percentage to be selected is",X_percent)
    Z_percent = float(input("Enter the probability of mutation for each gene (e.g., 10 for 10%): "))
    print("The percentage to be selected for mutation is ",Z_percent)
    
    X = X_percent / 100
    Z = Z_percent / 100
    #Here we are asking users to enter which kind of algorithm has to be implemented
    Crossover_ALG = input("Enter the crossover algorithm to use (uniform or k_point): ")
    
    return Chromosomes_Size, Num_Generations, X, Z, Crossover_ALG

if __name__ == '__main__':
    chromosomes_size, num_generations, x, z, crossover_alg = get_user_input()
    gene_data = load_gene_data()#get the gene data
    
    population = [initialize_chromosome_with_mean_and_standard_deviation(gene_data) for _ in range(chromosomes_size)]#Initialize the population

    print("initial population is")
    for populationIndex in range(len(population)):
        print(population[populationIndex])#Here we are printing the initial population
    #Here we are initializing the population
    best_chromosome=None
    best_fitness=float('-inf')
    for i in range(num_generations):
        population = create_next_generation(population, x, z, crossover_alg, gene_data)
        if population is None:#Check if the population size is None
            print('Could not generate the new population by the roulette wheel selection algorithm')
            exit(0)

        if (i + 1) % 10 == 0:
            all_fitness = [chr.fitness for chr in population]
            print(f'Generation {i+1}')#Here we are printing the generation
            print('Max fitness:', max(all_fitness))#Maximum fitness
            print('Min fitness:', min(all_fitness))#Overall fitness score
            print('Average fitness:', sum(all_fitness) / len(all_fitness))#Average fitness score
            for chr in population:
                if chr.fitness>best_fitness:
                    best_chromosome=chr
                    best_fitness=chr.fitness
    print("-------------------Results----------")
    print('Best Fitness is fitness:', max(chr.fitness for chr in population))
    #Here we are printing the maximum fitness
    print("Best chromosome is",best_chromosome)
    #Here we are printing the chromosome which is best

    print('Final population:')
    for individual_chromosome in range(len(population)):
        print(population[individual_chromosome])#Here we are printing the population
