This Project is written by Pradyumna
The main objective of this project is to maximize the profits and to print the best chromosome
Insturction to run is python GeneticAlgorithmByPradyumnaBuyOrStock.py
Later specify the parameters accordingly as the input is asked
When the input for entering the file name is asked enter with .txt only as this project can handle only .txt extensions as of now
After specifying the parameters wait for sometime to see the output